    <!-- component -->
         </div>
              <div class="absolute bottom-0 left-0 py-6 px-6">
                  <div class="flex space-x-2">
                    <p class="text-green-400 font-semibold">Explore</p>
                  </div>
              </div>
              <div class="absolute bottom-0 py-6 px-6 right-0">
                <p class="text-green-400 font-semibold">Explore</p>
              </div>
          </div>
      </section>
    </div>    
  <!-- component -->